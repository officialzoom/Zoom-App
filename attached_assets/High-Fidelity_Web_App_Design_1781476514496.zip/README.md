
  # High-Fidelity Web App Design

  This is a code bundle for High-Fidelity Web App Design. The original project is available at https://www.figma.com/design/3nOhvPJh7xQn4PA8KrzDc1/High-Fidelity-Web-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  