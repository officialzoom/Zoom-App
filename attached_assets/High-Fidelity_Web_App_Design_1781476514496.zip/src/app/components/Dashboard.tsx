import { useState } from "react";
import {
  TrendingUp,
  Car,
  Bus,
  Truck,
  ChevronRight,
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  Users,
  Star,
  Zap,
} from "lucide-react";

const neu = {
  raised: {
    boxShadow: "6px 6px 14px #d1d5db, -6px -6px 14px #ffffff",
  },
  sunken: {
    boxShadow: "inset 4px 4px 10px #d1d5db, inset -4px -4px 10px #ffffff",
  },
  card: {
    boxShadow: "8px 8px 20px #d1d5db, -8px -8px 20px #ffffff",
  },
  yellowBtn: {
    boxShadow: "4px 4px 10px #c49a24, -3px -3px 8px #ffe97d",
  },
  whiteBtn: {
    boxShadow: "4px 4px 10px #d1d5db, -3px -3px 8px #ffffff",
  },
};

const assetTiers = [
  {
    id: 1,
    icon: Car,
    label: "Normal Cars",
    category: "Sedan & Hatchback",
    entry: "₦5,000",
    returnRate: "40%",
    duration: "3 days",
    slots: 72,
    totalSlots: 100,
    tag: "Low Entry",
    tagColor: "#22c55e",
    color: "#3b82f6",
    bg: "#eff6ff",
    description: "Toyota Camry, Honda Accord, Kia Rio",
  },
  {
    id: 2,
    icon: Bus,
    label: "Buses & Vans",
    category: "Commercial Transit",
    entry: "₦25,000",
    returnRate: "55%",
    duration: "7 days",
    slots: 45,
    totalSlots: 80,
    tag: "Medium Entry",
    tagColor: "#f59e0b",
    color: "#8b5cf6",
    bg: "#f5f3ff",
    description: "Hiace Bus, Toyota HiAce, Ford Transit",
  },
  {
    id: 3,
    icon: Truck,
    label: "Heavy Duty Trucks",
    category: "Logistics & Freight",
    entry: "₦100,000",
    returnRate: "80%",
    duration: "14 days",
    slots: 18,
    totalSlots: 40,
    tag: "High Entry",
    tagColor: "#ef4444",
    color: "#f59e0b",
    bg: "#fffbeb",
    description: "Mack Trucks, DAF XF, Howo A7",
  },
];

const recentActivity = [
  { type: "return", label: "Investment Return — Toyota Camry", amount: "+₦7,000", date: "Today, 09:14 AM", status: "completed" },
  { type: "deposit", label: "Wallet Top-up via Bank Transfer", amount: "+₦50,000", date: "Yesterday, 2:30 PM", status: "completed" },
  { type: "invest", label: "Invested — Hiace Bus Fleet", amount: "-₦25,000", date: "Jun 10, 11:00 AM", status: "active" },
  { type: "return", label: "Investment Return — Kia Rio", amount: "+₦3,500", date: "Jun 9, 8:45 AM", status: "completed" },
];

export function Dashboard() {
  const [lockDays, setLockDays] = useState(7);
  const [investAmount, setInvestAmount] = useState(50000);

  const returnRate = lockDays <= 3 ? 0.4 : lockDays <= 7 ? 0.55 : 0.8;
  const payout = Math.round(investAmount * (1 + returnRate));

  return (
    <div className="flex flex-col gap-8">
      {/* Hero Wallet Card */}
      <div
        className="rounded-3xl p-8 relative overflow-hidden"
        style={{ background: "#FFFFFF", ...neu.card }}
      >
        {/* Recessed inner tray */}
        <div
          className="rounded-2xl p-6 mb-6"
          style={{ background: "#F4F5F7", ...neu.sunken }}
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#6B7280" }}>
                Total Wallet Balance
              </p>
              <p className="mt-1" style={{ fontSize: "2rem", fontWeight: 800, color: "#1A1A1A", lineHeight: 1.2 }}>
                ₦482,500
              </p>
              <p className="text-sm mt-1" style={{ color: "#6B7280" }}>Available for investment</p>
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#6B7280" }}>
                Active Investments Value
              </p>
              <p className="mt-1" style={{ fontSize: "2rem", fontWeight: 800, color: "#1A1A1A", lineHeight: 1.2 }}>
                ₦175,000
              </p>
              <p className="text-sm mt-1 flex items-center gap-1" style={{ color: "#22c55e" }}>
                <TrendingUp size={14} /> +12.4% this week
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#6B7280" }}>
                Total Earnings (Lifetime)
              </p>
              <p className="mt-1" style={{ fontSize: "2rem", fontWeight: 800, color: "#FBC02D", lineHeight: 1.2 }}>
                ₦94,200
              </p>
              <p className="text-sm mt-1 flex items-center gap-1" style={{ color: "#6B7280" }}>
                <Star size={12} fill="#FBC02D" color="#FBC02D" /> Top 8% of investors
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4">
          <button
            className="flex items-center gap-2 px-8 py-3 rounded-2xl font-bold transition-all active:scale-95"
            style={{ background: "#FBC02D", color: "#1A1A1A", ...neu.yellowBtn, border: "none", cursor: "pointer" }}
          >
            <ArrowDownLeft size={18} />
            Deposit Funds
          </button>
          <button
            className="flex items-center gap-2 px-8 py-3 rounded-2xl font-bold transition-all active:scale-95"
            style={{ background: "#FFFFFF", color: "#1A1A1A", ...neu.whiteBtn, border: "none", cursor: "pointer" }}
          >
            <ArrowUpRight size={18} />
            Withdraw
          </button>
          <div
            className="flex items-center gap-2 px-6 py-3 rounded-2xl ml-auto"
            style={{ background: "#F4F5F7", ...neu.sunken }}
          >
            <Wallet size={16} style={{ color: "#6B7280" }} />
            <span className="text-sm font-semibold" style={{ color: "#6B7280" }}>Wallet ID: ZM-0042-NG</span>
          </div>
        </div>
      </div>

      {/* Asset Marketplace */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="font-bold" style={{ fontSize: "1.35rem", color: "#1A1A1A" }}>Asset Marketplace</h2>
            <p className="text-sm mt-0.5" style={{ color: "#6B7280" }}>Choose a vehicle tier to invest in</p>
          </div>
          <button className="flex items-center gap-1 text-sm font-semibold" style={{ color: "#FBC02D", background: "none", border: "none", cursor: "pointer" }}>
            View All <ChevronRight size={16} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {assetTiers.map((tier) => {
            const Icon = tier.icon;
            const fillPct = Math.round((tier.slots / tier.totalSlots) * 100);
            return (
              <div
                key={tier.id}
                className="rounded-2xl p-5 flex flex-col gap-4 cursor-pointer transition-all hover:scale-[1.02]"
                style={{ background: "#FFFFFF", ...neu.raised }}
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{ background: tier.bg, ...neu.sunken }}
                  >
                    <Icon size={22} style={{ color: tier.color }} />
                  </div>
                  <span
                    className="text-xs font-bold px-3 py-1 rounded-full"
                    style={{ background: tier.tagColor + "18", color: tier.tagColor }}
                  >
                    {tier.tag}
                  </span>
                </div>

                {/* Title */}
                <div>
                  <p className="font-bold" style={{ fontSize: "1.05rem", color: "#1A1A1A" }}>{tier.label}</p>
                  <p className="text-xs mt-0.5" style={{ color: "#6B7280" }}>{tier.description}</p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: "Min. Entry", value: tier.entry },
                    { label: "Return", value: tier.returnRate },
                    { label: "Duration", value: tier.duration },
                  ].map((s) => (
                    <div
                      key={s.label}
                      className="rounded-xl p-2 text-center"
                      style={{ background: "#F4F5F7", ...neu.sunken }}
                    >
                      <p className="text-xs" style={{ color: "#6B7280" }}>{s.label}</p>
                      <p className="font-bold text-sm mt-0.5" style={{ color: "#1A1A1A" }}>{s.value}</p>
                    </div>
                  ))}
                </div>

                {/* Progress */}
                <div>
                  <div className="flex justify-between text-xs mb-1.5" style={{ color: "#6B7280" }}>
                    <span>{tier.slots} slots remaining</span>
                    <span>{fillPct}% filled</span>
                  </div>
                  <div
                    className="w-full h-2 rounded-full overflow-hidden"
                    style={{ background: "#F4F5F7", ...neu.sunken }}
                  >
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${fillPct}%`, background: `linear-gradient(90deg, ${tier.color}cc, ${tier.color})` }}
                    />
                  </div>
                </div>

                {/* CTA */}
                <button
                  className="w-full py-2.5 rounded-xl font-bold text-sm transition-all active:scale-95"
                  style={{ background: "#FBC02D", color: "#1A1A1A", ...neu.yellowBtn, border: "none", cursor: "pointer" }}
                >
                  Invest Now
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Investment Customizer */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div
          className="rounded-2xl p-6"
          style={{ background: "#FFFFFF", ...neu.card }}
        >
          <div className="flex items-center gap-2 mb-5">
            <Zap size={18} style={{ color: "#FBC02D" }} />
            <h3 className="font-bold" style={{ fontSize: "1.05rem" }}>Investment Customizer</h3>
          </div>

          {/* Amount Input */}
          <div className="mb-5">
            <label className="text-sm font-semibold block mb-2" style={{ color: "#6B7280" }}>
              Investment Amount (₦)
            </label>
            <div className="relative">
              <span
                className="absolute left-4 top-1/2 -translate-y-1/2 font-bold"
                style={{ color: "#FBC02D", fontSize: "1.1rem" }}
              >
                ₦
              </span>
              <input
                type="number"
                value={investAmount}
                onChange={(e) => setInvestAmount(Number(e.target.value))}
                className="w-full pl-10 pr-4 py-3 rounded-xl font-bold outline-none"
                style={{ background: "#F4F5F7", ...neu.sunken, color: "#1A1A1A", border: "none", fontSize: "1.1rem" }}
              />
            </div>
            <div className="flex gap-2 mt-2">
              {[5000, 25000, 50000, 100000].map((v) => (
                <button
                  key={v}
                  onClick={() => setInvestAmount(v)}
                  className="flex-1 py-1.5 rounded-lg text-xs font-bold transition-all"
                  style={{
                    background: investAmount === v ? "#FBC02D" : "#F4F5F7",
                    color: investAmount === v ? "#1A1A1A" : "#6B7280",
                    ...(investAmount === v ? neu.yellowBtn : neu.sunken),
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  ₦{v.toLocaleString()}
                </button>
              ))}
            </div>
          </div>

          {/* Lock Days Slider */}
          <div className="mb-5">
            <div className="flex justify-between mb-2">
              <label className="text-sm font-semibold" style={{ color: "#6B7280" }}>
                Lock-up Period
              </label>
              <span className="text-sm font-bold flex items-center gap-1" style={{ color: "#1A1A1A" }}>
                <Clock size={13} /> {lockDays} days
              </span>
            </div>
            <div
              className="px-1 py-3 rounded-xl"
              style={{ background: "#F4F5F7", ...neu.sunken }}
            >
              <input
                type="range"
                min={3}
                max={30}
                value={lockDays}
                onChange={(e) => setLockDays(Number(e.target.value))}
                className="w-full"
                style={{ accentColor: "#FBC02D" }}
              />
            </div>
            <div className="flex justify-between text-xs mt-1" style={{ color: "#6B7280" }}>
              <span>Min. 3 days</span>
              <span>Max. 30 days</span>
            </div>
          </div>

          {/* Earnings Preview */}
          <div
            className="rounded-xl p-4"
            style={{ background: "#F4F5F7", ...neu.sunken }}
          >
            <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: "#6B7280" }}>
              Live Earnings Preview
            </p>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm" style={{ color: "#6B7280" }}>You Invest</p>
                <p className="font-bold" style={{ fontSize: "1.2rem", color: "#1A1A1A" }}>
                  ₦{investAmount.toLocaleString()}
                </p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-8 h-0.5 my-1" style={{ background: "#FBC02D" }} />
                <span className="text-xs font-bold" style={{ color: "#FBC02D" }}>
                  +{Math.round(returnRate * 100)}%
                </span>
                <div className="w-8 h-0.5 my-1" style={{ background: "#FBC02D" }} />
              </div>
              <div className="text-right">
                <p className="text-sm" style={{ color: "#6B7280" }}>You Receive</p>
                <p className="font-bold" style={{ fontSize: "1.2rem", color: "#22c55e" }}>
                  ₦{payout.toLocaleString()}
                </p>
              </div>
            </div>
            <div className="mt-3 text-xs text-center" style={{ color: "#6B7280" }}>
              Profit: <span style={{ color: "#22c55e", fontWeight: 700 }}>+₦{(payout - investAmount).toLocaleString()}</span> upon maturity in {lockDays} days
            </div>
          </div>

          <button
            className="w-full py-3 rounded-xl font-bold mt-4 transition-all active:scale-95"
            style={{ background: "#FBC02D", color: "#1A1A1A", ...neu.yellowBtn, border: "none", cursor: "pointer" }}
          >
            Confirm Investment
          </button>
        </div>

        {/* Recent Activity */}
        <div
          className="rounded-2xl p-6"
          style={{ background: "#FFFFFF", ...neu.card }}
        >
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-bold" style={{ fontSize: "1.05rem" }}>Recent Activity</h3>
            <span className="text-xs font-semibold px-3 py-1 rounded-full" style={{ background: "#FBC02D18", color: "#FBC02D" }}>
              4 transactions
            </span>
          </div>

          <div className="flex flex-col gap-3">
            {recentActivity.map((a, i) => (
              <div
                key={i}
                className="flex items-center gap-3 p-3 rounded-xl"
                style={{ background: "#F4F5F7", ...neu.sunken }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: a.type === "return" ? "#dcfce7" : a.type === "deposit" ? "#dbeafe" : "#fef9c3",
                  }}
                >
                  {a.type === "return" ? (
                    <TrendingUp size={16} style={{ color: "#22c55e" }} />
                  ) : a.type === "deposit" ? (
                    <ArrowDownLeft size={16} style={{ color: "#3b82f6" }} />
                  ) : (
                    <Car size={16} style={{ color: "#f59e0b" }} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: "#1A1A1A" }}>{a.label}</p>
                  <p className="text-xs" style={{ color: "#6B7280" }}>{a.date}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p
                    className="font-bold text-sm"
                    style={{ color: a.amount.startsWith("+") ? "#22c55e" : "#ef4444" }}
                  >
                    {a.amount}
                  </p>
                  <span
                    className="text-xs font-semibold px-2 py-0.5 rounded-full"
                    style={{
                      background: a.status === "completed" ? "#dcfce7" : "#fef9c3",
                      color: a.status === "completed" ? "#16a34a" : "#b45309",
                    }}
                  >
                    {a.status}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-2 gap-3 mt-4">
            {[
              { icon: Users, label: "Total Investors", value: "12,847", color: "#8b5cf6" },
              { icon: TrendingUp, label: "Platform Returns", value: "₦4.2B", color: "#22c55e" },
            ].map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.label} className="rounded-xl p-3" style={{ background: "#F4F5F7", ...neu.sunken }}>
                  <Icon size={14} style={{ color: s.color }} />
                  <p className="text-xs mt-1" style={{ color: "#6B7280" }}>{s.label}</p>
                  <p className="font-bold mt-0.5" style={{ color: "#1A1A1A" }}>{s.value}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
