import { useState } from "react";
import {
  Upload,
  Target,
  Megaphone,
  Heart,
  CheckCircle,
  ChevronDown,
  Users,
  MapPin,
  TrendingUp,
  Image as ImageIcon,
} from "lucide-react";

const neu = {
  raised: { boxShadow: "6px 6px 14px #d1d5db, -6px -6px 14px #ffffff" },
  sunken: { boxShadow: "inset 4px 4px 10px #d1d5db, inset -4px -4px 10px #ffffff" },
  card: { boxShadow: "8px 8px 20px #d1d5db, -8px -8px 20px #ffffff" },
  yellowBtn: { boxShadow: "4px 4px 10px #c49a24, -3px -3px 8px #ffe97d" },
  whiteBtn: { boxShadow: "4px 4px 10px #d1d5db, -3px -3px 8px #ffffff" },
};

const audienceOptions = ["Lagos — All Areas", "Abuja — FCT", "Port Harcourt", "Kano", "Ibadan", "Nationwide (All States)"];
const durationOptions = ["3 days — ₦5,000", "7 days — ₦10,000", "14 days — ₦18,000", "30 days — ₦35,000"];
const donationGoals = [
  { id: 1, title: "Fleet Maintenance Fund", target: 2000000, raised: 1340000, desc: "Covers routine servicing, tyre changes, and oil top-ups for the active fleet.", color: "#3b82f6" },
  { id: 2, title: "Driver Welfare & Insurance", target: 500000, raised: 387000, desc: "Supports driver health benefits, accident insurance, and emergency funds.", color: "#22c55e" },
  { id: 3, title: "New Vehicle Acquisition", target: 5000000, raised: 2100000, desc: "Expanding the Zoom fleet with 5 new commercial vehicles in Q3 2026.", color: "#8b5cf6" },
];

export function RunAds() {
  const [bannerFile, setBannerFile] = useState<string | null>(null);
  const [audience, setAudience] = useState(audienceOptions[0]);
  const [duration, setDuration] = useState(durationOptions[0]);
  const [adTitle, setAdTitle] = useState("");
  const [adLink, setAdLink] = useState("");
  const [audienceOpen, setAudienceOpen] = useState(false);
  const [durationOpen, setDurationOpen] = useState(false);
  const [donateAmounts, setDonateAmounts] = useState<Record<number, number>>({ 1: 5000, 2: 2000, 3: 10000 });
  const [submitted, setSubmitted] = useState(false);

  const selectedDurationCost = parseInt(duration.split("₦")[1]?.replace(",", "") || "5000");

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h2 className="font-bold" style={{ fontSize: "1.35rem", color: "#1A1A1A" }}>Ad Portal & Donations</h2>
        <p className="text-sm mt-0.5" style={{ color: "#6B7280" }}>Reach millions of Nigerian commuters or support platform logistics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Ad Portal Card */}
        <div className="rounded-2xl p-6 flex flex-col gap-5" style={{ background: "#FFFFFF", ...neu.card }}>
          <div className="flex items-center gap-3">
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center"
              style={{ background: "#fffbeb", ...neu.sunken }}
            >
              <Megaphone size={20} style={{ color: "#FBC02D" }} />
            </div>
            <div>
              <h3 className="font-bold" style={{ fontSize: "1.05rem" }}>Run an Advertisement</h3>
              <p className="text-xs" style={{ color: "#6B7280" }}>Display your banner on active Zoom fleet vehicles</p>
            </div>
          </div>

          {/* Banner Upload */}
          <div>
            <label className="text-sm font-semibold block mb-2" style={{ color: "#6B7280" }}>
              Ad Banner (PNG, JPG, or GIF)
            </label>
            <label
              className="flex flex-col items-center justify-center gap-2 rounded-xl p-6 cursor-pointer transition-all"
              style={{ background: "#F4F5F7", ...neu.sunken, border: "2px dashed rgba(0,0,0,0.1)" }}
            >
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) setBannerFile(f.name);
                }}
              />
              {bannerFile ? (
                <div className="flex items-center gap-2">
                  <CheckCircle size={18} style={{ color: "#22c55e" }} />
                  <span className="text-sm font-semibold" style={{ color: "#1A1A1A" }}>{bannerFile}</span>
                </div>
              ) : (
                <>
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{ background: "#FFFFFF", ...neu.raised }}
                  >
                    <Upload size={20} style={{ color: "#FBC02D" }} />
                  </div>
                  <p className="text-sm font-semibold" style={{ color: "#1A1A1A" }}>Drop banner here or click to upload</p>
                  <p className="text-xs" style={{ color: "#6B7280" }}>Recommended: 1200×400px, max 5MB</p>
                </>
              )}
            </label>
          </div>

          {/* Ad Title */}
          <div>
            <label className="text-sm font-semibold block mb-2" style={{ color: "#6B7280" }}>
              Campaign Title
            </label>
            <input
              type="text"
              value={adTitle}
              onChange={(e) => setAdTitle(e.target.value)}
              placeholder="e.g. Grand Opening — Emeka's Superstore"
              className="w-full px-4 py-3 rounded-xl outline-none"
              style={{ background: "#F4F5F7", ...neu.sunken, color: "#1A1A1A", border: "none" }}
            />
          </div>

          {/* Destination URL */}
          <div>
            <label className="text-sm font-semibold block mb-2" style={{ color: "#6B7280" }}>
              Destination URL
            </label>
            <input
              type="url"
              value={adLink}
              onChange={(e) => setAdLink(e.target.value)}
              placeholder="https://yourwebsite.com"
              className="w-full px-4 py-3 rounded-xl outline-none"
              style={{ background: "#F4F5F7", ...neu.sunken, color: "#1A1A1A", border: "none" }}
            />
          </div>

          {/* Target Audience */}
          <div className="relative">
            <label className="text-sm font-semibold block mb-2" style={{ color: "#6B7280" }}>
              <Target size={14} className="inline mr-1" /> Target Audience Location
            </label>
            <button
              onClick={() => { setAudienceOpen(!audienceOpen); setDurationOpen(false); }}
              className="w-full px-4 py-3 rounded-xl text-left flex items-center justify-between font-semibold"
              style={{ background: "#F4F5F7", ...neu.sunken, color: "#1A1A1A", border: "none", cursor: "pointer" }}
            >
              <span className="flex items-center gap-2">
                <MapPin size={15} style={{ color: "#FBC02D" }} />
                {audience}
              </span>
              <ChevronDown size={16} style={{ transform: audienceOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
            </button>
            {audienceOpen && (
              <div
                className="absolute z-20 w-full mt-2 rounded-xl overflow-hidden"
                style={{ background: "#FFFFFF", ...neu.raised }}
              >
                {audienceOptions.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => { setAudience(opt); setAudienceOpen(false); }}
                    className="w-full px-4 py-2.5 text-left text-sm font-semibold hover:bg-[#F4F5F7] transition-colors"
                    style={{ color: audience === opt ? "#FBC02D" : "#1A1A1A", border: "none", background: "none", cursor: "pointer" }}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Duration */}
          <div className="relative">
            <label className="text-sm font-semibold block mb-2" style={{ color: "#6B7280" }}>
              Campaign Duration
            </label>
            <button
              onClick={() => { setDurationOpen(!durationOpen); setAudienceOpen(false); }}
              className="w-full px-4 py-3 rounded-xl text-left flex items-center justify-between font-semibold"
              style={{ background: "#F4F5F7", ...neu.sunken, color: "#1A1A1A", border: "none", cursor: "pointer" }}
            >
              {duration}
              <ChevronDown size={16} style={{ transform: durationOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
            </button>
            {durationOpen && (
              <div
                className="absolute z-20 w-full mt-2 rounded-xl overflow-hidden"
                style={{ background: "#FFFFFF", ...neu.raised }}
              >
                {durationOptions.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => { setDuration(opt); setDurationOpen(false); }}
                    className="w-full px-4 py-2.5 text-left text-sm font-semibold hover:bg-[#F4F5F7] transition-colors"
                    style={{ color: duration === opt ? "#FBC02D" : "#1A1A1A", border: "none", background: "none", cursor: "pointer" }}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Checkout Summary */}
          <div className="rounded-xl p-4" style={{ background: "#F4F5F7", ...neu.sunken }}>
            <div className="flex justify-between items-center text-sm">
              <span style={{ color: "#6B7280" }}>Campaign cost</span>
              <span className="font-bold" style={{ color: "#1A1A1A" }}>₦{selectedDurationCost.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center text-sm mt-1">
              <span style={{ color: "#6B7280" }}>Wallet balance</span>
              <span className="font-bold" style={{ color: "#22c55e" }}>₦482,500</span>
            </div>
            <div className="h-px my-2" style={{ background: "rgba(0,0,0,0.08)" }} />
            <div className="flex justify-between items-center">
              <span className="font-bold" style={{ color: "#1A1A1A" }}>Balance after</span>
              <span className="font-bold" style={{ color: "#1A1A1A" }}>₦{(482500 - selectedDurationCost).toLocaleString()}</span>
            </div>
          </div>

          <button
            className="w-full py-3 rounded-xl font-bold transition-all active:scale-95"
            style={{ background: "#FBC02D", color: "#1A1A1A", ...neu.yellowBtn, border: "none", cursor: "pointer" }}
          >
            Launch Campaign — Pay ₦{selectedDurationCost.toLocaleString()} from Wallet
          </button>

          {/* Reach Stats */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { icon: Users, label: "Est. Reach", value: "85K+" },
              { icon: ImageIcon, label: "Impressions", value: "420K" },
              { icon: TrendingUp, label: "Avg. CTR", value: "3.2%" },
            ].map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.label} className="rounded-xl p-2.5 text-center" style={{ background: "#F4F5F7", ...neu.sunken }}>
                  <Icon size={13} style={{ color: "#FBC02D", margin: "0 auto" }} />
                  <p className="text-xs mt-1" style={{ color: "#6B7280" }}>{s.label}</p>
                  <p className="font-bold text-sm" style={{ color: "#1A1A1A" }}>{s.value}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Donation Column */}
        <div className="flex flex-col gap-4">
          <div className="rounded-2xl p-5" style={{ background: "#FFFFFF", ...neu.card }}>
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center"
                style={{ background: "#fff1f2", ...neu.sunken }}
              >
                <Heart size={20} style={{ color: "#ef4444" }} />
              </div>
              <div>
                <h3 className="font-bold" style={{ fontSize: "1.05rem" }}>Support Platform Goals</h3>
                <p className="text-xs" style={{ color: "#6B7280" }}>Crowdsource Zoom's logistics & operations</p>
              </div>
            </div>
            <p className="text-sm" style={{ color: "#6B7280" }}>
              Your donations fund vehicle maintenance, driver welfare, and fleet expansion — keeping Nigeria's roads moving.
            </p>
          </div>

          {donationGoals.map((goal) => {
            const pct = Math.round((goal.raised / goal.target) * 100);
            return (
              <div key={goal.id} className="rounded-2xl p-5" style={{ background: "#FFFFFF", ...neu.raised }}>
                <div className="flex items-start justify-between mb-2">
                  <p className="font-bold" style={{ color: "#1A1A1A" }}>{goal.title}</p>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ background: goal.color + "18", color: goal.color }}>
                    {pct}%
                  </span>
                </div>
                <p className="text-xs mb-3" style={{ color: "#6B7280" }}>{goal.desc}</p>

                <div className="flex justify-between text-xs mb-1.5" style={{ color: "#6B7280" }}>
                  <span>₦{goal.raised.toLocaleString()} raised</span>
                  <span>Goal: ₦{goal.target.toLocaleString()}</span>
                </div>
                <div className="h-2 rounded-full overflow-hidden mb-3" style={{ background: "#F4F5F7", ...neu.sunken }}>
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${goal.color}88, ${goal.color})` }}
                  />
                </div>

                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-sm" style={{ color: "#FBC02D" }}>₦</span>
                    <input
                      type="number"
                      value={donateAmounts[goal.id]}
                      onChange={(e) => setDonateAmounts((prev) => ({ ...prev, [goal.id]: Number(e.target.value) }))}
                      className="w-full pl-8 pr-3 py-2.5 rounded-xl outline-none font-semibold text-sm"
                      style={{ background: "#F4F5F7", ...neu.sunken, color: "#1A1A1A", border: "none" }}
                    />
                  </div>
                  <button
                    onClick={() => setSubmitted(true)}
                    className="px-5 py-2.5 rounded-xl font-bold text-sm transition-all active:scale-95"
                    style={{ background: "#FBC02D", color: "#1A1A1A", ...neu.yellowBtn, border: "none", cursor: "pointer" }}
                  >
                    Donate
                  </button>
                </div>
              </div>
            );
          })}

          {submitted && (
            <div
              className="rounded-2xl p-4 flex items-center gap-3"
              style={{ background: "#dcfce7", boxShadow: "inset 2px 2px 6px #bbf7d0, inset -2px -2px 6px #f0fdf4" }}
            >
              <CheckCircle size={20} style={{ color: "#16a34a" }} />
              <p className="text-sm font-semibold" style={{ color: "#15803d" }}>
                Thank you! Your donation has been processed from your wallet.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
