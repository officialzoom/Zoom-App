import { useState } from "react";
import {
  ShieldCheck,
  Plus,
  ChevronRight,
  AlertCircle,
  Clock,
  Trash2,
  Camera,
  CheckCircle,
  Eye,
  EyeOff,
  CreditCard,
  Bell,
  Lock,
  LogOut,
} from "lucide-react";

const neu = {
  raised: { boxShadow: "6px 6px 14px #d1d5db, -6px -6px 14px #ffffff" },
  sunken: { boxShadow: "inset 4px 4px 10px #d1d5db, inset -4px -4px 10px #ffffff" },
  card: { boxShadow: "8px 8px 20px #d1d5db, -8px -8px 20px #ffffff" },
  yellowBtn: { boxShadow: "4px 4px 10px #c49a24, -3px -3px 8px #ffe97d" },
  whiteBtn: { boxShadow: "4px 4px 10px #d1d5db, -3px -3px 8px #ffffff" },
};

const linkedBanks = [
  { id: 1, name: "GTBank", accountName: "Chukwuemeka Obi", accountNo: "••••••7892", logo: "GT", color: "#f97316", bg: "#fff7ed" },
  { id: 2, name: "Access Bank", accountName: "Chukwuemeka Obi", accountNo: "••••••3341", logo: "AC", color: "#dc2626", bg: "#fef2f2" },
];

const settingsItems = [
  { icon: Bell, label: "Notification Preferences", desc: "SMS, email and push alerts" },
  { icon: Lock, label: "Security & 2FA", desc: "Two-factor authentication" },
  { icon: CreditCard, label: "Transaction PIN", desc: "Manage your 4-digit PIN" },
];

export function Profile() {
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [selectedBank, setSelectedBank] = useState(1);
  const [showAmount, setShowAmount] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [addingBank, setAddingBank] = useState(false);

  const handleSubmit = () => {
    if (withdrawAmount && Number(withdrawAmount) > 0) {
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 4000);
      setWithdrawAmount("");
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Profile Identity Card */}
      <div className="rounded-2xl p-6" style={{ background: "#FFFFFF", ...neu.card }}>
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div
              className="w-24 h-24 rounded-2xl flex items-center justify-center relative overflow-hidden"
              style={{ background: "linear-gradient(135deg, #FBC02D, #f59e0b)", ...neu.raised }}
            >
              <span style={{ fontSize: "2rem", fontWeight: 800, color: "#1A1A1A" }}>CO</span>
            </div>
            <button
              className="absolute -bottom-1 -right-1 w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ background: "#FFFFFF", ...neu.raised, border: "none", cursor: "pointer" }}
            >
              <Camera size={14} style={{ color: "#6B7280" }} />
            </button>
          </div>

          {/* Identity */}
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 flex-wrap">
              <h2 className="font-bold" style={{ fontSize: "1.4rem", color: "#1A1A1A" }}>Chukwuemeka Obi</h2>
              <span
                className="flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold"
                style={{ background: "#dcfce7", color: "#16a34a" }}
              >
                <ShieldCheck size={12} /> KYC Verified
              </span>
            </div>
            <p className="text-sm mt-1" style={{ color: "#6B7280" }}>chukwuemeka.obi@gmail.com</p>
            <p className="text-sm" style={{ color: "#6B7280" }}>+234 803 456 7890 · Lagos, Nigeria</p>
            <div className="flex items-center justify-center md:justify-start gap-3 mt-3 flex-wrap">
              {[
                { label: "Member Since", value: "Jan 2024" },
                { label: "Investor Level", value: "Gold" },
                { label: "Referrals", value: "12 users" },
              ].map((s) => (
                <div
                  key={s.label}
                  className="px-3 py-1.5 rounded-xl"
                  style={{ background: "#F4F5F7", ...neu.sunken }}
                >
                  <p className="text-xs" style={{ color: "#6B7280" }}>{s.label}</p>
                  <p className="text-sm font-bold" style={{ color: "#1A1A1A" }}>{s.value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Logout */}
          <button
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold"
            style={{ background: "#fff1f2", color: "#ef4444", ...neu.whiteBtn, border: "none", cursor: "pointer" }}
          >
            <LogOut size={14} /> Sign Out
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Linked Bank Accounts */}
        <div className="rounded-2xl p-6" style={{ background: "#FFFFFF", ...neu.card }}>
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-bold" style={{ fontSize: "1.05rem" }}>Linked Bank Accounts</h3>
            <button
              onClick={() => setAddingBank(!addingBank)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-bold transition-all active:scale-95"
              style={{ background: "#FBC02D", color: "#1A1A1A", ...neu.yellowBtn, border: "none", cursor: "pointer" }}
            >
              <Plus size={14} /> Add Account
            </button>
          </div>

          <div className="flex flex-col gap-3">
            {linkedBanks.map((bank) => (
              <div
                key={bank.id}
                onClick={() => setSelectedBank(bank.id)}
                className="flex items-center gap-4 p-4 rounded-xl cursor-pointer transition-all"
                style={{
                  background: selectedBank === bank.id ? "#fffbeb" : "#F4F5F7",
                  ...(selectedBank === bank.id ? neu.sunken : neu.sunken),
                  outline: selectedBank === bank.id ? "2px solid #FBC02D" : "2px solid transparent",
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center font-bold"
                  style={{ background: bank.bg, color: bank.color, fontSize: "0.85rem" }}
                >
                  {bank.logo}
                </div>
                <div className="flex-1">
                  <p className="font-bold text-sm" style={{ color: "#1A1A1A" }}>{bank.name}</p>
                  <p className="text-xs" style={{ color: "#6B7280" }}>{bank.accountName}</p>
                  <p className="text-xs font-semibold mt-0.5" style={{ color: "#6B7280" }}>{bank.accountNo}</p>
                </div>
                <div className="flex items-center gap-2">
                  {selectedBank === bank.id && (
                    <CheckCircle size={16} style={{ color: "#FBC02D" }} />
                  )}
                  <button
                    className="p-1.5 rounded-lg"
                    style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444" }}
                    onClick={(e) => { e.stopPropagation(); }}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}

            {addingBank && (
              <div
                className="rounded-xl p-4 flex flex-col gap-3"
                style={{ background: "#F4F5F7", ...neu.sunken }}
              >
                <p className="text-sm font-bold" style={{ color: "#1A1A1A" }}>Add New Bank Account</p>
                {["Bank Name", "Account Number", "Account Name"].map((placeholder) => (
                  <input
                    key={placeholder}
                    type="text"
                    placeholder={placeholder}
                    className="w-full px-3 py-2.5 rounded-lg outline-none text-sm"
                    style={{ background: "#FFFFFF", ...neu.raised, color: "#1A1A1A", border: "none" }}
                  />
                ))}
                <button
                  className="w-full py-2.5 rounded-xl font-bold text-sm transition-all active:scale-95"
                  style={{ background: "#FBC02D", color: "#1A1A1A", ...neu.yellowBtn, border: "none", cursor: "pointer" }}
                >
                  Verify & Link Account
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Withdrawal Interface */}
        <div className="rounded-2xl p-6" style={{ background: "#FFFFFF", ...neu.card }}>
          <h3 className="font-bold mb-5" style={{ fontSize: "1.05rem" }}>Request Withdrawal</h3>

          {/* Balance Display */}
          <div
            className="rounded-xl p-4 mb-4 flex items-center justify-between"
            style={{ background: "#F4F5F7", ...neu.sunken }}
          >
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: "#6B7280" }}>Available Balance</p>
              <p className="font-bold mt-1" style={{ fontSize: "1.5rem", color: "#1A1A1A" }}>
                {showAmount ? "₦482,500" : "₦•••,•••"}
              </p>
            </div>
            <button
              onClick={() => setShowAmount(!showAmount)}
              className="p-2 rounded-lg"
              style={{ background: "none", border: "none", cursor: "pointer", color: "#6B7280" }}
            >
              {showAmount ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          {/* Destination Bank */}
          <div className="mb-4">
            <label className="text-sm font-semibold block mb-2" style={{ color: "#6B7280" }}>
              Withdrawal Destination
            </label>
            <div
              className="flex items-center gap-3 p-3 rounded-xl"
              style={{ background: "#F4F5F7", ...neu.sunken }}
            >
              {linkedBanks.find((b) => b.id === selectedBank) && (
                <>
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold"
                    style={{
                      background: linkedBanks.find((b) => b.id === selectedBank)!.bg,
                      color: linkedBanks.find((b) => b.id === selectedBank)!.color,
                    }}
                  >
                    {linkedBanks.find((b) => b.id === selectedBank)!.logo}
                  </div>
                  <div>
                    <p className="text-sm font-bold" style={{ color: "#1A1A1A" }}>
                      {linkedBanks.find((b) => b.id === selectedBank)!.name}
                    </p>
                    <p className="text-xs" style={{ color: "#6B7280" }}>
                      {linkedBanks.find((b) => b.id === selectedBank)!.accountNo}
                    </p>
                  </div>
                </>
              )}
              <ChevronRight size={16} className="ml-auto" style={{ color: "#6B7280" }} />
            </div>
          </div>

          {/* Amount Input */}
          <div className="mb-4">
            <label className="text-sm font-semibold block mb-2" style={{ color: "#6B7280" }}>
              Withdrawal Amount (₦)
            </label>
            <div className="relative">
              <span
                className="absolute left-4 top-1/2 -translate-y-1/2 font-bold"
                style={{ color: "#FBC02D", fontSize: "1.1rem" }}
              >
                ₦
              </span>
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="0.00"
                className="w-full pl-10 pr-4 py-3 rounded-xl outline-none font-bold"
                style={{ background: "#F4F5F7", ...neu.sunken, color: "#1A1A1A", border: "none", fontSize: "1.1rem" }}
              />
            </div>
            <div className="flex gap-2 mt-2">
              {[10000, 25000, 50000, 100000].map((v) => (
                <button
                  key={v}
                  onClick={() => setWithdrawAmount(String(v))}
                  className="flex-1 py-1.5 rounded-lg text-xs font-bold transition-all"
                  style={{
                    background: withdrawAmount === String(v) ? "#FBC02D" : "#F4F5F7",
                    color: withdrawAmount === String(v) ? "#1A1A1A" : "#6B7280",
                    ...(withdrawAmount === String(v) ? neu.yellowBtn : neu.sunken),
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  ₦{(v / 1000)}K
                </button>
              ))}
            </div>
          </div>

          {/* Notice Badge */}
          <div
            className="rounded-xl p-4 mb-5 flex gap-3"
            style={{ background: "#fffbeb", boxShadow: "inset 2px 2px 6px #f5e4a0, inset -2px -2px 6px #fffde7" }}
          >
            <AlertCircle size={18} className="flex-shrink-0 mt-0.5" style={{ color: "#f59e0b" }} />
            <div>
              <p className="text-xs font-bold mb-0.5" style={{ color: "#92400e" }}>Processing Notice</p>
              <p className="text-xs leading-relaxed" style={{ color: "#92400e" }}>
                Withdrawals take up to <strong>12 hours</strong> to process into your commercial bank account for security verification. You will receive an SMS confirmation once the transfer is initiated.
              </p>
            </div>
          </div>

          {/* Processing Time Visual */}
          <div
            className="rounded-xl p-3 mb-5 flex items-center gap-3"
            style={{ background: "#F4F5F7", ...neu.sunken }}
          >
            <Clock size={16} style={{ color: "#6B7280" }} />
            <div className="flex-1">
              <div className="flex gap-1">
                {Array.from({ length: 12 }, (_, i) => (
                  <div
                    key={i}
                    className="h-1.5 flex-1 rounded-full"
                    style={{ background: i < 3 ? "#FBC02D" : "#E8E9EC" }}
                  />
                ))}
              </div>
              <p className="text-xs mt-1" style={{ color: "#6B7280" }}>Avg. processing: 2–4 hours · Max: 12 hours</p>
            </div>
          </div>

          {/* Submit Button — Glossy tactile yellow */}
          <button
            onClick={handleSubmit}
            className="w-full py-4 rounded-2xl font-bold text-base transition-all active:scale-95 relative overflow-hidden"
            style={{ background: "linear-gradient(135deg, #FFD54F, #FBC02D, #F9A825)", color: "#1A1A1A", ...neu.yellowBtn, border: "none", cursor: "pointer" }}
          >
            {/* Glossy sheen */}
            <div
              className="absolute inset-x-0 top-0 h-1/2 rounded-t-2xl pointer-events-none"
              style={{ background: "linear-gradient(to bottom, rgba(255,255,255,0.4), rgba(255,255,255,0))" }}
            />
            Submit Withdrawal Request
          </button>

          {submitted && (
            <div
              className="mt-3 rounded-xl p-3 flex items-center gap-2"
              style={{ background: "#dcfce7", boxShadow: "inset 2px 2px 6px #bbf7d0" }}
            >
              <CheckCircle size={16} style={{ color: "#16a34a" }} />
              <p className="text-sm font-semibold" style={{ color: "#15803d" }}>
                Withdrawal submitted! You'll receive an SMS once processed.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Account Settings Row */}
      <div className="rounded-2xl p-6" style={{ background: "#FFFFFF", ...neu.card }}>
        <h3 className="font-bold mb-4" style={{ fontSize: "1.05rem" }}>Account Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {settingsItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                className="flex items-center gap-3 p-4 rounded-xl text-left transition-all hover:scale-[1.02] active:scale-95"
                style={{ background: "#F4F5F7", ...neu.raised, border: "none", cursor: "pointer" }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: "#FFFFFF", ...neu.sunken }}
                >
                  <Icon size={16} style={{ color: "#FBC02D" }} />
                </div>
                <div>
                  <p className="text-sm font-bold" style={{ color: "#1A1A1A" }}>{item.label}</p>
                  <p className="text-xs" style={{ color: "#6B7280" }}>{item.desc}</p>
                </div>
                <ChevronRight size={14} className="ml-auto flex-shrink-0" style={{ color: "#6B7280" }} />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
