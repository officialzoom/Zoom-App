import { useState } from "react";
import { Dashboard } from "./components/Dashboard";
import { RunAds } from "./components/RunAds";
import { Profile } from "./components/Profile";
import {
  LayoutDashboard,
  Car,
  Megaphone,
  User,
  Wallet,
  Bell,
  ChevronDown,
  Zap,
  Menu,
  X,
} from "lucide-react";

{/* MARKER-MAKE-KIT-INVOKED */}

const neu = {
  raised: { boxShadow: "6px 6px 14px #d1d5db, -6px -6px 14px #ffffff" },
  sunken: { boxShadow: "inset 4px 4px 10px #d1d5db, inset -4px -4px 10px #ffffff" },
  yellowBtn: { boxShadow: "4px 4px 10px #c49a24, -3px -3px 8px #ffe97d" },
};

type Page = "dashboard" | "explore" | "ads" | "profile";

const navItems: { id: Page; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "explore", label: "Explore Assets", icon: Car },
  { id: "ads", label: "Run Ads", icon: Megaphone },
  { id: "profile", label: "Profile", icon: User },
];

export default function App() {
  const [page, setPage] = useState<Page>("dashboard");
  const [menuOpen, setMenuOpen] = useState(false);

  const pageTitle: Record<Page, string> = {
    dashboard: "Investment Dashboard",
    explore: "Explore Assets",
    ads: "Ad Portal & Donations",
    profile: "Profile & Wallet",
  };

  return (
    <div
      className="min-h-screen"
      style={{ background: "#F4F5F7", fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}
    >
      {/* Top Navigation Bar */}
      <nav
        className="sticky top-0 z-50 px-4 md:px-8"
        style={{ background: "#FFFFFF", boxShadow: "0 4px 20px rgba(0,0,0,0.08), 0 -1px 0 rgba(255,255,255,0.9) inset" }}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between h-16 gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2.5 flex-shrink-0">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #FFD54F, #FBC02D)", ...neu.raised }}
            >
              <Zap size={18} style={{ color: "#1A1A1A" }} />
            </div>
            <span style={{ fontWeight: 800, fontSize: "1.3rem", color: "#1A1A1A", letterSpacing: "-0.02em" }}>
              zoom
            </span>
            <span
              className="text-xs font-bold px-2 py-0.5 rounded-full hidden md:inline"
              style={{ background: "rgba(251,192,45,0.12)", color: "#FBC02D" }}
            >
              NG
            </span>
          </div>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = page === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setPage(item.id)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all"
                  style={{
                    background: active ? "#FBC02D" : "transparent",
                    color: active ? "#1A1A1A" : "#6B7280",
                    ...(active ? neu.yellowBtn : {}),
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  <Icon size={15} />
                  {item.label}
                </button>
              );
            })}
          </div>

          {/* Right Side Controls */}
          <div className="flex items-center gap-2 md:gap-3">
            {/* Wallet Balance Chip */}
            <div
              className="hidden md:flex items-center gap-2 px-4 py-2 rounded-xl"
              style={{ background: "#F4F5F7", ...neu.sunken }}
            >
              <Wallet size={14} style={{ color: "#FBC02D" }} />
              <div>
                <p className="text-xs" style={{ color: "#6B7280", lineHeight: 1 }}>Wallet</p>
                <p className="text-sm font-bold" style={{ color: "#1A1A1A", lineHeight: 1.2 }}>₦482,500</p>
              </div>
              <ChevronDown size={13} style={{ color: "#6B7280" }} />
            </div>

            {/* Notifications */}
            <button
              className="relative w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "#F4F5F7", ...neu.raised, border: "none", cursor: "pointer" }}
            >
              <Bell size={16} style={{ color: "#6B7280" }} />
              <span
                className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
                style={{ background: "#FBC02D" }}
              />
            </button>

            {/* Avatar */}
            <button
              onClick={() => setPage("profile")}
              className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm"
              style={{ background: "linear-gradient(135deg, #FFD54F, #FBC02D)", ...neu.raised, border: "none", cursor: "pointer", color: "#1A1A1A" }}
            >
              CO
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "#F4F5F7", ...neu.raised, border: "none", cursor: "pointer" }}
            >
              {menuOpen ? <X size={16} /> : <Menu size={16} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {menuOpen && (
          <div className="md:hidden border-t pb-3 pt-2" style={{ borderColor: "rgba(0,0,0,0.06)" }}>
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = page === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => { setPage(item.id); setMenuOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-sm font-semibold"
                  style={{
                    background: active ? "#fffbeb" : "none",
                    color: active ? "#FBC02D" : "#6B7280",
                    border: "none",
                    cursor: "pointer",
                    borderRadius: "0.75rem",
                  }}
                >
                  <Icon size={16} />
                  {item.label}
                </button>
              );
            })}
          </div>
        )}
      </nav>

      {/* Page Content */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        {/* Page Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1
              style={{ fontWeight: 800, fontSize: "clamp(1.4rem, 3vw, 1.75rem)", color: "#1A1A1A", lineHeight: 1.2 }}
            >
              {pageTitle[page]}
            </h1>
            <p className="text-sm mt-1" style={{ color: "#6B7280" }}>
              {page === "dashboard" && "Welcome back, Chukwuemeka 👋 — here's your portfolio overview"}
              {page === "explore" && "Browse all available fractional vehicle investment opportunities"}
              {page === "ads" && "Advertise on our fleet or support community-driven logistics goals"}
              {page === "profile" && "Manage your identity, linked accounts, and withdrawal requests"}
            </p>
          </div>

          {page === "dashboard" && (
            <div className="flex items-center gap-2">
              <div
                className="px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-bold"
                style={{ background: "#dcfce7", color: "#16a34a" }}
              >
                <span
                  className="w-1.5 h-1.5 rounded-full inline-block"
                  style={{ background: "#22c55e", animation: "pulse 2s infinite" }}
                />
                Markets Live
              </div>
            </div>
          )}
        </div>

        {/* Render Active Page */}
        {page === "dashboard" && <Dashboard />}
        {page === "explore" && (
          <div
            className="rounded-2xl p-10 text-center"
            style={{ background: "#FFFFFF", boxShadow: "8px 8px 20px #d1d5db, -8px -8px 20px #ffffff" }}
          >
            <div
              className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4"
              style={{ background: "#fffbeb", boxShadow: "inset 4px 4px 10px #f5e4a0, inset -4px -4px 10px #fffde7" }}
            >
              <Car size={36} style={{ color: "#FBC02D" }} />
            </div>
            <h2 className="font-bold mb-2" style={{ fontSize: "1.3rem" }}>Full Asset Explorer</h2>
            <p style={{ color: "#6B7280", maxWidth: "400px", margin: "0 auto" }}>
              Browse the complete catalogue of fractional vehicle investment opportunities across Nigeria. Filter by tier, return rate, and city.
            </p>
            <button
              className="mt-6 px-8 py-3 rounded-xl font-bold transition-all active:scale-95"
              style={{ background: "#FBC02D", color: "#1A1A1A", boxShadow: "4px 4px 10px #c49a24, -3px -3px 8px #ffe97d", border: "none", cursor: "pointer" }}
              onClick={() => setPage("dashboard")}
            >
              View Investment Tiers
            </button>
          </div>
        )}
        {page === "ads" && <RunAds />}
        {page === "profile" && <Profile />}
      </main>

      {/* Bottom Mobile Nav */}
      <div
        className="md:hidden fixed bottom-0 inset-x-0 flex items-center justify-around py-2 px-2"
        style={{ background: "#FFFFFF", boxShadow: "0 -4px 20px rgba(0,0,0,0.08)" }}
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = page === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className="flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl"
              style={{ background: "none", border: "none", cursor: "pointer" }}
            >
              <div
                className="w-8 h-8 flex items-center justify-center rounded-xl"
                style={active ? { background: "#FBC02D", boxShadow: "3px 3px 6px #c49a24, -2px -2px 5px #ffe97d" } : {}}
              >
                <Icon size={16} style={{ color: active ? "#1A1A1A" : "#6B7280" }} />
              </div>
              <span className="text-xs font-semibold" style={{ color: active ? "#FBC02D" : "#9CA3AF" }}>
                {item.label.split(" ")[0]}
              </span>
            </button>
          );
        })}
      </div>

      {/* Bottom padding for mobile nav */}
      <div className="md:hidden h-20" />
    </div>
  );
}
